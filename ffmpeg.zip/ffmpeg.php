<?php
class ffmpeg
{        
        private $videoName = '';
        
        private $tmp_name = '';
        
        private $videoFileName = '';
        
        private $error='';
        
        private $newName = '';

        private $videoNewPith='./video/';
        
        private $imagePith='./image/';
    
        private $type;
        
        private $videoTimeForFrontCover = '8';
        
        private $removeFileName = '';

        public function setVideoNewPith($videoPith)
	{
            $this->$videoNewPith = $videoPith;
	}
        
        public function setImagePith($imagePith)
        {
            $filethis->imagePith = $imagePith;            
        }
        
        public function setNewName($newName)
        {
            $this->newName = $newName;
        }
        
        public function setVideoTimeForFrontCover($vidoeTime)
        {
            $this->videoTimeForFrontCover = $vidoeTime;
        }
        public function setRemoveFileName($name)
        {
            $this->removeFileName = $name;
        }
        
        public function setRemoveFileType($type)
        {
            $this->type = $type;
        }

        public function ffmpeg()
	{
           // echo '<pre>';print_r($_FILES);echo '</pre>';
           if(isset($_FILES['file']))
           {    
                $videoName = explode( '.', $_FILES['file']['name']);
                $this->videoName = $videoName[0];
                $this->videoFileName =  $_FILES['file']['name'];
                $this->type ='.'.$videoName[1];
                $this->tmp_name = $_FILES['file']['tmp_name'];
                $this->error = $_FILES['file']['error'];             
            }
        }
	
        private function uploadVideo()
        {   
            
            if($this->error > 0)
            {
                echo $this->error;
            }
            else
            {
                echo '<br/>'.'start upload';
                if(empty($this->newName)==false)
                {
                    $this->videoFileName = $this->newName.$this->type;
                }
                return move_uploaded_file( $this->tmp_name , $this->videoNewPith.$this->videoFileName );
            }
        }

        private function converterVideo()
	{
            if(empty($this->newName)==false)
            {
                $this->videoName = $this->newName;
            }
            echo '<br/>start get image';
            //exec("ffmpeg -i ".$this->videoNewPith.$this->videoFileName." -ar 22050 -ab 32 -f flv -s 640x480 ".$this->videoNewPith.$this->videoName.".flv");
            try {
                
                $cmd="ffmpeg -i ".$this->videoNewPith.$this->videoFileName." -y -f image2 -ss ".$this->videoTimeForFrontCover ." -t 0.001 -s 640x480 ".$this->imagePith.$this->videoName."_front_cover.jpg";
                $exec=exec($cmd);     
            } catch (Exception $exc) {
                echo $exc->getTraceAsString();
            }

            return $exec;
	}
        
        public function run()
        {
            if(is_file($this->videoNewPith.$this->videoName.".flv")==false) 
            {
                if($this->uploadVideo())
                {echo '<br/>'.'finish upload';
                    if($this->converterVideo())
                    {
                        return true;
                    }
                    else 
                    {
                        return FALSE;
                    }
                }
                else 
                {
                    return FALSE;
                }
            }
            else 
            {
                return FALSE;
            }
        }
        public function removeVideo()
        {
            
            
               echo $removeFile = $this->removeFileName.'.'.$this->type;
            
                   
            if(is_file($this->videoNewPith.$removeFile)) 
            {
              echo   unlink($this->imagePith.$this->removeFileName."_front_cover.jpg" );
               echo  unlink($this->videoNewPith.$removeFile );
            }
        }
}

?>